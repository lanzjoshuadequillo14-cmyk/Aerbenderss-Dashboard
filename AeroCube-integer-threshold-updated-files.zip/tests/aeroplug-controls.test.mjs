import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const html = readFileSync(new URL('../aeroplug.html', import.meta.url), 'utf8');
const script = readFileSync(new URL('../aeroplug.js', import.meta.url), 'utf8')
  .replace(/^import[^\r\n]*;\r?\n/gm, '');
const firebaseSource = readFileSync(new URL('../firebase.js', import.meta.url), 'utf8');
const basePath = firebaseSource.match(/const BASE_PATH\s*=\s*["']([^"']+)["']/)[1];

function loadAeroPlug({ cubeId = null, plugId = null } = {}) {
  const elements = new Map();
  const listeners = new Map();
  const writes = [];
  const controlsPath = '/Aerocubes/' + (cubeId || basePath.split('/').pop()) + '/controls';
  const statePath = '/aeroplugs/' + (plugId || 'plug_01') + '/state';
  let controls = {};
  let nextWrite = null;

  class Element {
    constructor(id) {
      this.id = id;
      this.className = '';
      this.textContent = '';
      this.innerText = '';
      this.checked = false;
      this.indeterminate = false;
      this.disabled = false;
      this.attributes = {};
      this.events = new Map();
      this.classList = {
        contains: name => this.className.split(/\s+/).includes(name),
        toggle: (name, force) => {
          const names = new Set(this.className.split(/\s+/).filter(Boolean));
          if (force ?? !names.has(name)) names.add(name);
          else names.delete(name);
          this.className = [...names].join(' ');
        }
      };
    }
    addEventListener(name, callback) { this.events.set(name, callback); }
    setAttribute(name, value) { this.attributes[name] = value; }
  }

  for (const match of html.matchAll(/id="([^"]+)"/g)) {
    elements.set(match[1], new Element(match[1]));
  }

  function publishControls(value) {
    controls = { ...value };
    listeners.get(controlsPath).callback({ val: () => ({ ...controls }) });
  }

  const context = vm.createContext({
    document: { getElementById: id => elements.get(id) ?? null },
    window: { location: {} },
    localStorage: {
      getItem: key => ({ 'aerocube-id': cubeId, 'aeroplug-id': plugId })[key] ?? null
    },
    console,
    db: {}, auth: {}, BASE_PATH: basePath,
    ref: (db, path) => path,
    onValue: (path, callback, error) => listeners.set(path, { callback, error }),
    update: (path, partial) => {
      writes.push({ path, value: { ...partial } });
      assert.equal(path, controlsPath, 'Control requests must target the selected AeroCube.');
      const previous = { ...controls };
      // Firebase delivers local optimistic values before its write promise settles.
      publishControls({ ...controls, ...partial });
      const pending = nextWrite;
      nextWrite = null;
      return (pending?.promise ?? Promise.resolve()).catch(error => {
        // A rejected Firebase write also restores the prior subscription value.
        publishControls(previous);
        throw error;
      });
    },
    onAuthStateChanged() {}, signOut: async () => {}, setInterval() {}
  });
  vm.runInContext(script, context, { filename: 'aeroplug.js' });

  return {
    elements, listeners, writes, controlsPath, statePath,
    run: code => vm.runInContext(code, context),
    publishControls,
    publishState: value => listeners.get(statePath).callback({ val: () => value }),
    getControls: () => ({ ...controls }),
    trigger(id, event, checked) {
      const element = elements.get(id);
      if (checked !== undefined) element.checked = checked;
      return element.events.get(event)({ target: element, preventDefault() {} });
    },
    deferNextWrite() {
      assert.equal(nextWrite, null);
      let resolve;
      let reject;
      const promise = new Promise((resolveWrite, rejectWrite) => {
        resolve = resolveWrite;
        reject = rejectWrite;
      });
      nextWrite = { promise };
      return { resolve, reject };
    }
  };
}

test('AeroPlug uses the selected device and the firmware default without initial writes', () => {
  const fallback = loadAeroPlug();
  assert.equal(fallback.controlsPath, '/Aerocubes/aerocube_01/controls');
  assert.ok(fallback.listeners.has('/aeroplugs/plug_01/state'));
  assert.equal(fallback.writes.length, 0);
  assert.equal(fallback.elements.get('switch-relay1').disabled, true);
  assert.equal(fallback.elements.get('switch-relay2').disabled, true);

  const selected = loadAeroPlug({ cubeId: 'lab_cube_07', plugId: 'plug_lab_02' });
  assert.ok(selected.listeners.has('/Aerocubes/lab_cube_07/controls'));
  assert.ok(selected.listeners.has('/aeroplugs/plug_lab_02/state'));
  assert.equal(selected.writes.length, 0);
});

test('automatic indicators follow Boolean reported states rather than stale manual requests', () => {
  const page = loadAeroPlug();
  page.publishState({ relay1: true, relay2: false });
  page.publishControls({ isAutoMode: true, manualRelay1: false, manualRelay2: true });
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: ON');
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: OFF');
  assert.equal(page.elements.get('switch-relay1').checked, true);
  assert.equal(page.elements.get('switch-relay2').checked, false);
  assert.equal(page.elements.get('switch-relay1').disabled, true);

  page.publishState({ relay1: 'false', relay2: 1 });
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: Unknown');
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: Unknown');
  assert.equal(page.elements.get('switch-relay1').indeterminate, true);
  page.publishState(null);
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: Unknown');
  assert.equal(page.writes.length, 0);
});

test('manual switches save independent Boolean requests without claiming a reported output change', async () => {
  const page = loadAeroPlug({ cubeId: 'lab_cube_07' });
  page.publishState({ relay1: false, relay2: true });
  page.publishControls({ isAutoMode: false, manualRelay1: true, manualRelay2: false, unrelated: 'keep' });
  assert.equal(page.elements.get('switch-relay1').checked, true);
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: OFF');
  assert.equal(page.elements.get('switch-relay2').checked, false);
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: ON');

  await page.trigger('switch-relay1', 'change', false);
  await page.trigger('switch-relay2', 'change', true);
  assert.deepEqual(page.writes, [
    { path: '/Aerocubes/lab_cube_07/controls', value: { manualRelay1: false } },
    { path: '/Aerocubes/lab_cube_07/controls', value: { manualRelay2: true } }
  ]);
  assert.equal(page.getControls().unrelated, 'keep');
  assert.equal(page.getControls().isAutoMode, false);
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: OFF');
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: ON');
  assert.match(page.elements.get('feedback-relay1').textContent, /saved to Firebase/);
  assert.match(page.elements.get('feedback-relay2').textContent, /reported state/);
  page.publishState({ relay1: true, relay2: false });
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: ON');
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: OFF');
  assert.equal(page.elements.get('switch-relay1').checked, false);
});

test('pending manual writes disable controls and reject concurrent mode and outlet requests', async () => {
  const page = loadAeroPlug();
  page.publishControls({ isAutoMode: false, manualRelay1: false, manualRelay2: false });
  page.publishState({ relay1: false, relay2: false });
  const deferred = page.deferNextWrite();
  const pending = page.trigger('switch-relay1', 'change', true);
  assert.equal(page.elements.get('switch-relay1').checked, true, 'The optimistic manual request is visible.');
  assert.equal(page.elements.get('switch-relay1').disabled, true);
  assert.equal(page.elements.get('switch-relay2').disabled, true);
  assert.equal(page.elements.get('btn-auto').disabled, true);
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: OFF');
  await page.trigger('switch-relay2', 'change', true);
  await page.trigger('btn-auto', 'click');
  assert.equal(page.writes.length, 1);
  deferred.resolve();
  await pending;
  assert.equal(page.elements.get('switch-relay1').disabled, false);
  assert.equal(page.elements.get('switch-relay2').checked, false);
  assert.equal(page.getControls().isAutoMode, false);
});

test('mode saves write only isAutoMode and never change reported outlet labels', async () => {
  const page = loadAeroPlug();
  page.publishControls({ isAutoMode: false, manualRelay1: false, manualRelay2: true });
  page.publishState({ relay1: true, relay2: false });
  await page.trigger('btn-auto', 'click');
  assert.deepEqual(page.writes, [
    { path: page.controlsPath, value: { isAutoMode: true } }
  ]);
  assert.equal(page.elements.get('switch-relay1').disabled, true);
  assert.equal(page.elements.get('switch-relay1').checked, true);
  assert.equal(page.elements.get('btn-auto').attributes['aria-pressed'], 'true');
  assert.match(page.elements.get('mode-feedback').textContent, /saved to Firebase/);
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: ON');
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: OFF');
  assert.equal(page.getControls().manualRelay1, false);
  assert.equal(page.getControls().manualRelay2, true);
});

test('a failed optimistic mode write restores the saved mode and displays its error', async () => {
  const page = loadAeroPlug();
  page.publishControls({ isAutoMode: false, manualRelay1: false, manualRelay2: true });
  page.publishState({ relay1: true, relay2: false });
  const deferred = page.deferNextWrite();
  const pending = page.trigger('btn-auto', 'click');
  assert.equal(page.getControls().isAutoMode, true, 'Firebase first emits its optimistic mode.');
  assert.equal(page.elements.get('btn-manual').disabled, true);
  deferred.reject(new Error('permission-denied'));
  await pending;
  assert.equal(page.getControls().isAutoMode, false);
  assert.equal(page.elements.get('btn-manual').attributes['aria-pressed'], 'true');
  assert.equal(page.elements.get('switch-relay1').disabled, false);
  assert.equal(page.elements.get('switch-relay1').checked, false);
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: ON');
  assert.match(page.elements.get('mode-feedback').textContent, /Could not save.*permission-denied/);
  assert.equal(page.elements.get('mode-feedback').classList.contains('error'), true);
});

test('a failed optimistic manual request restores its saved switch without changing reported state', async () => {
  const page = loadAeroPlug();
  page.publishControls({ isAutoMode: false, manualRelay1: false, manualRelay2: false });
  page.publishState({ relay1: true, relay2: false });
  const deferred = page.deferNextWrite();
  const pending = page.trigger('switch-relay1', 'change', true);
  assert.equal(page.getControls().manualRelay1, true);
  deferred.reject(new Error('permission-denied'));
  await pending;
  assert.equal(page.getControls().manualRelay1, false);
  assert.equal(page.elements.get('switch-relay1').checked, false);
  assert.equal(page.elements.get('switch-relay1').disabled, false);
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: ON');
  assert.match(page.elements.get('feedback-relay1').textContent, /Could not save.*permission-denied/);
});

test('missing, malformed, automatic, or unreadable modes cannot send manual requests', async () => {
  const page = loadAeroPlug();
  await page.trigger('switch-relay1', 'change', true);
  for (const mode of [undefined, null, 'false', 0, true]) {
    page.publishControls({ isAutoMode: mode, manualRelay1: false, manualRelay2: false });
    assert.equal(page.elements.get('switch-relay1').disabled, true);
    await page.trigger('switch-relay1', 'change', true);
  }
  page.publishControls({ isAutoMode: false, manualRelay1: false, manualRelay2: false });
  await page.run("updateManualRelay('manualRelay1', 'true')");
  await page.run("updateManualRelay('unexpectedControl', true)");
  await page.run("updateMode('false')");
  page.listeners.get(page.controlsPath).error(new Error('permission-denied'));
  await page.trigger('switch-relay1', 'change', true);
  assert.equal(page.elements.get('switch-relay1').disabled, true);
  assert.match(page.elements.get('mode-feedback').textContent, /Could not load.*permission-denied/);
  assert.equal(page.writes.length, 0);
});

test('reported-state subscription failures clear the output feedback to Unknown', () => {
  const page = loadAeroPlug();
  page.publishControls({ isAutoMode: true });
  page.publishState({ relay1: true, relay2: false });
  page.listeners.get(page.statePath).error(new Error('permission-denied'));
  assert.equal(page.elements.get('text-relay1').innerText, 'Reported: Unknown');
  assert.equal(page.elements.get('text-relay2').innerText, 'Reported: Unknown');
  assert.match(page.elements.get('reported-state-feedback').textContent, /Could not load.*permission-denied/);
  assert.equal(page.writes.length, 0);
});
