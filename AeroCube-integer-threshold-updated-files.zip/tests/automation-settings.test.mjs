import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const DEFAULT_DEVICE = 'aerocube_01';
const thresholdPath = device => `/Aerocubes/${device}/settings/automationThresholds`;
const fieldNames = { co2: 'co2Threshold', voc: 'vocThreshold', pm25: 'pm2p5Threshold' };

// Run the real page module with a small DOM and a recorded Firebase boundary.
// These tests exercise dashboard writes, not ESP32 firmware or physical relays.
function loadSettings({ storage = {}, database = {}, failWrite, deferWrites = false } = {}) {
  const elements = new Map();
  const subscriptions = new Map();
  const subscriptionErrors = new Map();
  const writes = [];
  const pendingWrites = [];
  const authObservers = [];
  const errors = [];
  const stored = new Map(Object.entries(storage));
  const state = structuredClone(database);
  const html = readFileSync(new URL('../settings.html', import.meta.url), 'utf8');

  class Element {
    get value() { return this._value ?? ''; }
    set value(value) { this._value = String(value); }
    constructor(tagName = 'div', attributes = {}) {
      this.tagName = tagName.toUpperCase();
      this.attributes = { ...attributes };
      this.id = attributes.id ?? '';
      this.value = attributes.value ?? '';
      this.min = attributes.min ?? '';
      this.max = attributes.max ?? '';
      this.step = attributes.step ?? '';
      this.type = attributes.type ?? '';
      this.disabled = 'disabled' in attributes;
      this.checked = 'checked' in attributes;
      this.hidden = 'hidden' in attributes;
      this.className = attributes.class ?? '';
      this.dataset = {};
      for (const [key, value] of Object.entries(attributes)) {
        if (key.startsWith('data-')) {
          this.dataset[key.slice(5).replace(/-([a-z])/g, (_, char) => char.toUpperCase())] = value;
        }
      }
      this.style = { setProperty(name, value) { this[name] = value; } };
      this.listeners = new Map();
      this.children = [];
      this.textContent = '';
      this.innerText = '';
      this.innerHTML = '';
      this.classList = {
        contains: name => this.className.split(/\s+/).includes(name),
        add: (...names) => { this.className = [...new Set([...this.className.split(/\s+/).filter(Boolean), ...names])].join(' '); },
        remove: (...names) => { this.className = this.className.split(/\s+/).filter(name => !names.includes(name)).join(' '); },
        toggle: (name, force) => {
          const present = this.classList.contains(name);
          const next = force ?? !present;
          this.classList[next ? 'add' : 'remove'](name);
          return next;
        }
      };
    }
    addEventListener(type, listener) {
      const listeners = this.listeners.get(type) ?? [];
      listeners.push(listener);
      this.listeners.set(type, listeners);
    }
    dispatchEvent(event) {
      event.target = this;
      event.currentTarget = this;
      for (const listener of this.listeners.get(event.type) ?? []) listener(event);
      return !event.defaultPrevented;
    }
    setAttribute(name, value) {
      this.attributes[name] = String(value);
      if (name === 'class') this.className = String(value);
    }
    getAttribute(name) { return this.attributes[name] ?? null; }
    removeAttribute(name) { delete this.attributes[name]; }
    appendChild(element) {
      element.parentNode = this;
      this.children.push(element);
      if (element.id) elements.set(element.id, element);
      return element;
    }
    insertBefore(element) { return this.appendChild(element); }
    querySelectorAll() { return []; }
    focus() { document.activeElement = this; }
  }

  const body = new Element('body');
  for (const tag of html.matchAll(/<([a-z][\w:-]*)\b([^>]*)>/gi)) {
    const attributes = {};
    for (const match of tag[2].matchAll(/([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) {
      attributes[match[1]] = match[2] ?? match[3] ?? match[4] ?? '';
    }
    if (attributes.id) body.appendChild(new Element(tag[1], attributes));
  }
  const document = {
    body, head: new Element('head'), activeElement: null,
    getElementById: id => elements.get(id) ?? null,
    createElement: name => new Element(name),
    addEventListener() {},
    querySelectorAll(selector) {
      if (selector.startsWith('#')) return [elements.get(selector.slice(1))].filter(Boolean);
      if (selector.startsWith('.')) return [...elements.values()].filter(element => element.classList.contains(selector.slice(1)));
      return [];
    }
  };
  class TestEvent {
    constructor(type, options = {}) { this.type = type; Object.assign(this, options); }
    preventDefault() { this.defaultPrevented = true; }
  }
  const getState = path => path.split('/').filter(Boolean).reduce((value, key) => value?.[key], state);
  function setState(path, value) {
    const segments = path.split('/').filter(Boolean);
    const leaf = segments.pop();
    let parent = state;
    for (const segment of segments) parent = parent[segment] ??= {};
    parent[leaf] = value;
  }
  function notifySubscribers(path) {
    for (const [observedPath, callbacks] of subscriptions) {
      if (path !== observedPath && !path.startsWith(observedPath + '/') && !observedPath.startsWith(path + '/')) continue;
      const value = structuredClone(getState(observedPath));
      for (const callback of callbacks) callback({ val: () => value ?? null, exists: () => value != null });
    }
  }
  const context = vm.createContext({
    document, Event: TestEvent,
    console: { log() {}, warn() {}, error: (...args) => errors.push(args) },
    window: { location: { href: '', reload() {} }, innerWidth: 1024, addEventListener() {} },
    localStorage: { getItem: key => stored.get(key) ?? null, setItem: (key, value) => stored.set(key, String(value)) },
    db: {}, auth: {}, BASE_PATH: `/Aerocubes/${DEFAULT_DEVICE}`,
    ref: (_db, path) => path,
    onValue(path, callback, errorCallback) {
      const callbacks = subscriptions.get(path) ?? [];
      callbacks.push(callback);
      subscriptions.set(path, callbacks);
      if (errorCallback) subscriptionErrors.set(path, errorCallback);
      return () => {};
    },
    async update(path, values) {
      const write = { path, values: structuredClone(values) };
      writes.push(write);
      if (failWrite?.(write)) throw new Error('Firebase write rejected');
      const previousValues = Object.keys(values).map(key => [key, structuredClone(getState(`${path}/${key}`))]);
      for (const [key, value] of Object.entries(values)) setState(`${path}/${key}`, value);
      if (!deferWrites) return;
      const pending = new Promise((resolve, reject) => {
        pendingWrites.push({
          write,
          acknowledge: resolve,
          reject() {
            for (const [key, value] of previousValues) {
              if (value === undefined) delete getState(path)[key];
              else setState(`${path}/${key}`, value);
            }
            notifySubscribers(path);
            reject(new Error('Firebase write rejected'));
          }
        });
      });
      // Firebase publishes local data before its update Promise is acknowledged.
      notifySubscribers(path);
      await pending;
    },
    onAuthStateChanged: (_auth, callback) => authObservers.push(callback),
    signOut: async () => {},
    setTimeout() {}, clearTimeout() {}, setInterval() {},
    navigator: {}
  });
  const script = readFileSync(new URL('../settings.js', import.meta.url), 'utf8')
    .replace(/^import[^\r\n]*;\r?\n/gm, '');
  vm.runInContext(script, context, { filename: 'settings.js' });

  const element = id => {
    assert.ok(elements.has(id), `settings.html must provide #${id}`);
    return elements.get(id);
  };
  async function flush() { await new Promise(resolve => setImmediate(resolve)); }
  async function fire(id, type) {
    const target = element(id);
    const event = new TestEvent(type, { target, currentTarget: target });
    for (const listener of target.listeners.get(type) ?? []) await listener(event);
    await flush();
  }
  return {
    elements, subscriptions, writes, pendingWrites, errors, state, element, fire, flush, authObservers,
    location: context.window.location,
    async enter(key, value) {
      element(`std-input-${key}`).value = value;
      await fire(`std-input-${key}`, 'input');
    },
    async emitThresholds(value, device = stored.get('aerocube-id') ?? DEFAULT_DEVICE) {
      const callbacks = subscriptions.get(thresholdPath(device));
      assert.ok(callbacks?.length, 'subscribe to the selected device automationThresholds path');
      for (const callback of callbacks) callback({ val: () => value, exists: () => value != null });
      await flush();
    },
    async emitLocalThresholds() {
      notifySubscribers(thresholdPath(stored.get('aerocube-id') ?? DEFAULT_DEVICE));
      await flush();
    },
    async cancelThresholdSubscription() {
      const callback = subscriptionErrors.get(thresholdPath(stored.get('aerocube-id') ?? DEFAULT_DEVICE));
      assert.ok(callback, 'threshold subscription must handle Firebase read errors');
      callback(new Error('Firebase permission denied'));
      await flush();
    },
    feedback(key) {
      const item = element(`std-feedback-${key}`);
      return [item.textContent, item.innerText, item.innerHTML].filter(Boolean).join(' ');
    },
    getState
  };
}

const saved = { co2Threshold: 1000, vocThreshold: 50, pm2p5Threshold: 35 };

test('settings reads the firmware device by default and honors the existing device selector', () => {
  const page = loadSettings();
  assert.ok(page.subscriptions.has(thresholdPath(DEFAULT_DEVICE)));
  assert.equal(page.element('aerocube-id').value, DEFAULT_DEVICE);
  const selected = loadSettings({ storage: { 'aerocube-id': 'aerocube_lab', 'aeroplug-id': 'plug_lab' } });
  assert.ok(selected.subscriptions.has(thresholdPath('aerocube_lab')));
  assert.equal(selected.element('aerocube-id').value, 'aerocube_lab');
  assert.equal(selected.element('aeroplug-id').value, 'plug_lab');
  assert.ok([...selected.subscriptions.keys()].every(path => !path.endsWith('/settings')));
  assert.equal(page.authObservers.length, 1);
  page.authObservers[0](null);
  assert.equal(page.location.href, 'Registration.html');
});

test('threshold number inputs and sliders request whole-number steps', () => {
  const page = loadSettings();
  for (const key of Object.keys(fieldNames)) {
    assert.equal(page.element(`std-input-${key}`).min, '1');
    assert.equal(page.element(`std-input-${key}`).step, '1');
    assert.equal(page.element(`slider-${key}`).step, '1');
  }
  assert.equal(page.element('slider-pm25').min, '1');
});

test('loading saved integer thresholds shows the fixed fractional release point', async () => {
  const page = loadSettings();
  await page.emitThresholds({ co2Threshold: 1200, vocThreshold: 250, pm2p5Threshold: 13 });
  assert.equal(Number(page.element('std-input-co2').value), 1200);
  assert.equal(Number(page.element('std-input-voc').value), 250);
  assert.equal(Number(page.element('std-input-pm25').value), 13);
  assert.match(page.element('std-release-voc').textContent, /Activates at ≥250 Index; clears below 212\.5 Index\./);
  assert.match(page.element('std-release-pm25').textContent, /Activates at ≥13 µg\/m³; clears below 11\.05 µg\/m³\./);
  assert.equal(page.writes.length, 0, 'loading saved values must not write defaults');
});

test('saved fractional thresholds remain visible with an error until explicitly replaced by an integer', async () => {
  for (const key of Object.keys(fieldNames)) {
    const page = loadSettings();
    const existing = { ...saved, [fieldNames[key]]: 12.75 };
    await page.emitThresholds(existing);
    assert.equal(page.element(`std-input-${key}`).value, '12.75');
    assert.equal(page.element(`std-input-${key}`).getAttribute('aria-invalid'), 'true');
    assert.match(page.feedback(key), /whole number/i);
    assert.equal(page.writes.length, 0, 'loading a fractional value must not change Firebase');
    await page.fire(`std-save-${key}`, 'click');
    assert.equal(page.writes.length, 0, 'fractional saved values cannot be saved again');
    assert.equal(page.element(`std-input-${key}`).value, '12.75', 'never round or truncate saved values');
    await page.enter(key, '13');
    await page.fire(`std-save-${key}`, 'click');
    assert.deepEqual(page.writes, [{ path: thresholdPath(DEFAULT_DEVICE), values: { [fieldNames[key]]: 13 } }]);
    assert.equal(page.element(`std-input-${key}`).getAttribute('aria-invalid'), null);
    assert.match(page.feedback(key), /saved to Firebase/i);
  }
});

test('missing saved thresholds do not turn slider placeholders into saved defaults', async () => {
  const page = loadSettings();
  await page.emitThresholds(null);
  for (const key of Object.keys(fieldNames)) assert.equal(page.element(`std-input-${key}`).value, '');
  await page.fire('btn-save', 'click');
  assert.equal(page.writes.length, 0);
  for (const key of Object.keys(fieldNames)) assert.match(page.feedback(key), /enter|positive|valid|required|number/i);
});

test('each field saves only its exact integer numeric Firebase threshold', async () => {
  const page = loadSettings({ database: { Aerocubes: { aerocube_01: { settings: {
    automationThresholds: { ...saved, untouched: 'keep' },
    maintenance: { SPS30Clean: false }, relayAssignments: { co2: 'legacy' }
  }, controls: { isAutoMode: true } } } } });
  await page.emitThresholds(saved);
  for (const [key, value] of [['co2', '1450'], ['voc', '250'], ['pm25', '12']]) {
    await page.enter(key, value);
    await page.fire(`std-save-${key}`, 'click');
    const write = page.writes.at(-1);
    assert.equal(write.path, thresholdPath(DEFAULT_DEVICE));
    assert.deepEqual(write.values, { [fieldNames[key]]: Number(value) });
    assert.equal(typeof write.values[fieldNames[key]], 'number');
    assert.equal(Number.isSafeInteger(write.values[fieldNames[key]]), true);
    assert.match(page.feedback(key), /saved|firebase/i);
    assert.doesNotMatch(page.feedback(key), /outlet.*(?:switched|turned)|relay.*(?:switched|turned)/i);
  }
  assert.equal(page.writes.length, 3);
  assert.equal(page.getState(`${thresholdPath(DEFAULT_DEVICE)}/untouched`), 'keep');
  assert.equal(page.getState('/Aerocubes/aerocube_01/settings/maintenance/SPS30Clean'), false);
  assert.equal(page.getState('/Aerocubes/aerocube_01/settings/relayAssignments/co2'), 'legacy');
  assert.equal(page.getState('/Aerocubes/aerocube_01/controls/isAutoMode'), true);
  assert.ok(page.writes.every(write => !/controls|command|relayAssignments/.test(write.path)));
});

test('empty, nonnumeric, nonfinite, fractional, unsafe, zero and negative drafts cannot overwrite saved values', async () => {
  const invalidValues = ['', '   ', 'not a number', '12oops', 'NaN', 'Infinity', '-Infinity', '1e309', '0', '-1', '-0.5', '0.5', '12.75', '9007199254740992'];
  for (const key of Object.keys(fieldNames)) {
    const page = loadSettings();
    await page.emitThresholds(saved);
    for (const value of invalidValues) {
      await page.enter(key, value);
      await page.fire(`std-input-${key}`, 'change');
      await page.fire(`std-input-${key}`, 'blur');
      assert.equal(page.element(`std-input-${key}`).value, value, `${key}: preserve invalid draft ${JSON.stringify(value)}`);
      await page.fire(`std-save-${key}`, 'click');
      assert.equal(page.writes.length, 0, `${key}: reject ${JSON.stringify(value)}`);
      assert.match(page.feedback(key), /whole number/i);
      assert.equal(page.element(`std-input-${key}`).getAttribute('aria-invalid'), 'true');
    }
  }
});

test('an invalid PM2.5 draft does not block individual VOC or CO2 saves', async () => {
  const page = loadSettings();
  await page.emitThresholds(saved);
  await page.enter('pm25', '');
  await page.enter('voc', '250');
  await page.fire('std-save-voc', 'click');
  await page.enter('co2', '1250');
  await page.fire('std-save-co2', 'click');
  assert.deepEqual(page.writes.map(write => write.values), [{ vocThreshold: 250 }, { co2Threshold: 1250 }]);
  assert.equal(page.element('std-input-pm25').value, '');
});

test('bulk save validates each field independently when PM2.5 is fractional', async () => {
  const page = loadSettings();
  await page.emitThresholds(saved);
  await page.enter('co2', '1350');
  await page.enter('voc', '250');
  await page.enter('pm25', '12.75');
  await page.fire('btn-save', 'click');
  assert.equal(page.writes.length, 2);
  assert.deepEqual(page.writes.map(write => write.values).sort((a, b) => Object.keys(a)[0].localeCompare(Object.keys(b)[0])), [
    { co2Threshold: 1350 }, { vocThreshold: 250 }
  ]);
  assert.match(page.feedback('pm25'), /whole number/i);
  assert.equal(page.element('std-input-pm25').value, '12.75', 'fractional drafts are not rounded or truncated');
  assert.match(page.feedback('co2'), /saved|firebase/i);
  assert.match(page.feedback('voc'), /saved|firebase/i);
});

test('Firebase refreshes retain dirty drafts while updating untouched fields', async () => {
  const page = loadSettings();
  await page.emitThresholds(saved);
  await page.enter('voc', '250');
  await page.enter('pm25', '');
  await page.fire('std-input-pm25', 'blur');
  await page.emitThresholds({ co2Threshold: 1800, vocThreshold: 75, pm2p5Threshold: 20 });
  assert.equal(Number(page.element('std-input-co2').value), 1800);
  assert.equal(page.element('std-input-voc').value, '250');
  assert.equal(page.element('std-input-pm25').value, '');
  assert.equal(page.writes.length, 0);
});

test('reference buttons prepare a draft and require an explicit save', async () => {
  const page = loadSettings();
  await page.emitThresholds(saved);
  await page.fire('std-reset-voc', 'click');
  assert.equal(Number(page.element('std-input-voc').value), 150);
  assert.equal(page.writes.length, 0);
  await page.fire('std-save-voc', 'click');
  assert.deepEqual(page.writes.at(-1), { path: thresholdPath(DEFAULT_DEVICE), values: { vocThreshold: 150 } });
});

test('Firebase write failures are reported beside the affected field', async () => {
  const page = loadSettings({ failWrite: write => 'vocThreshold' in write.values });
  await page.emitThresholds(saved);
  await page.enter('voc', '250');
  await page.fire('std-save-voc', 'click');
  assert.match(page.feedback('voc'), /error|failed|could not|unable/i);
  assert.doesNotMatch(page.feedback('voc'), /saved successfully/i);
  assert.equal(page.element('std-input-voc').value, '250');
  await page.enter('co2', '1250');
  await page.fire('std-save-co2', 'click');
  assert.match(page.feedback('co2'), /saved|firebase/i);
});

test('optimistic Firebase snapshots cannot confirm a pending write or erase another field error', async () => {
  const page = loadSettings({
    deferWrites: true,
    database: { Aerocubes: { aerocube_01: { settings: { automationThresholds: saved } } } }
  });
  await page.emitThresholds(saved);
  await page.enter('pm25', '');
  await page.fire('std-save-pm25', 'click');
  const pmError = page.feedback('pm25');
  await page.enter('voc', '250');
  const saving = page.fire('std-save-voc', 'click');
  await page.flush();
  assert.equal(page.pendingWrites.length, 1);
  assert.equal(page.getState(`${thresholdPath(DEFAULT_DEVICE)}/vocThreshold`), 250, 'local Firebase value is optimistic');
  await page.emitLocalThresholds();
  assert.match(page.feedback('voc'), /saving/i);
  assert.doesNotMatch(page.feedback('voc'), /saved|success/i);
  assert.equal(page.element('std-input-voc').disabled, true);
  assert.equal(page.element('std-input-pm25').value, '');
  assert.equal(page.feedback('pm25'), pmError);
  assert.equal(page.element('std-input-pm25').getAttribute('aria-invalid'), 'true');
  page.pendingWrites[0].acknowledge();
  await saving;
  assert.match(page.feedback('voc'), /saved to Firebase/i);
  assert.equal(page.element('std-input-voc').disabled, false);
  assert.equal(page.feedback('pm25'), pmError);
  assert.equal(page.writes.length, 1);
});

test('bulk save protects an untouched missing PM2.5 error through other fields local snapshots', async () => {
  const existing = { co2Threshold: 1000, vocThreshold: 50 };
  const page = loadSettings({
    deferWrites: true,
    database: { Aerocubes: { aerocube_01: { settings: { automationThresholds: existing } } } }
  });
  await page.emitThresholds(existing);
  await page.enter('co2', '1350');
  await page.enter('voc', '250');
  // PM2.5 has never been edited; bulk validation itself must protect its error.
  const saving = page.fire('btn-save', 'click');
  await page.flush();
  assert.equal(page.pendingWrites.length, 2);
  const pmError = page.feedback('pm25');
  assert.match(pmError, /whole number/i);
  await page.emitLocalThresholds();
  assert.equal(page.feedback('pm25'), pmError);
  assert.equal(page.element('std-input-pm25').value, '');
  for (const key of ['co2', 'voc']) assert.doesNotMatch(page.feedback(key), /saved|success/i);
  for (const pending of page.pendingWrites) pending.acknowledge();
  await saving;
  assert.equal(page.feedback('pm25'), pmError);
  assert.equal(page.element('std-input-pm25').getAttribute('aria-invalid'), 'true');
  assert.equal(page.getState(`${thresholdPath(DEFAULT_DEVICE)}/pm2p5Threshold`), undefined);
  assert.deepEqual(page.writes.map(write => write.values), [{ co2Threshold: 1350 }, { vocThreshold: 250 }]);
  assert.equal(page.element('btn-save').disabled, false);
});

test('a rejected pending write and Firebase rollback retain the failed draft and reenable its controls', async () => {
  const page = loadSettings({
    deferWrites: true,
    database: { Aerocubes: { aerocube_01: { settings: { automationThresholds: saved } } } }
  });
  await page.emitThresholds(saved);
  await page.enter('voc', '250');
  const saving = page.fire('std-save-voc', 'click');
  await page.flush();
  assert.doesNotMatch(page.feedback('voc'), /saved|success/i);
  page.pendingWrites[0].reject();
  await saving;
  const writeError = page.feedback('voc');
  assert.match(writeError, /could not save/i);
  assert.equal(page.getState(`${thresholdPath(DEFAULT_DEVICE)}/vocThreshold`), 50, 'rejected optimistic value rolled back');
  // A later callback for the rollback must not clear the error or replace 250 with 50.
  await page.emitLocalThresholds();
  assert.equal(page.feedback('voc'), writeError);
  assert.equal(page.element('std-input-voc').value, '250');
  for (const prefix of ['std-input', 'std-save', 'std-reset', 'slider']) {
    assert.equal(page.element(`${prefix}-voc`).disabled, false);
  }
  assert.equal(page.writes.length, 1, 'no fallback default or automatic retry is written');
});

test('Firebase subscription cancellation reports each field error without writing defaults', async () => {
  const page = loadSettings();
  await page.cancelThresholdSubscription();
  for (const key of Object.keys(fieldNames)) {
    assert.match(page.feedback(key), /could not load.*Firebase/i);
    assert.equal(page.element(`std-input-${key}`).value, '');
  }
  assert.equal(page.writes.length, 0);
});
